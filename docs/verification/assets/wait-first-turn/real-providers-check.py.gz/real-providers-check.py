from pathlib import Path
import hashlib,json,os,shutil,signal,socket,subprocess,time

REPO=Path('/home/amlo/Projects/Rust/fleetpane')
BINARY=REPO/'target/debug/fleetpane-host'
ROOT=Path('/tmp/fp-wait-live-final');ROOT.mkdir(mode=0o700)
receipt={'binary_sha256':hashlib.sha256(BINARY.read_bytes()).hexdigest(),'providers':[],'cleanup':[]}
owned=[];credentials=[]

def raw(endpoint,request):
 with socket.socket(socket.AF_UNIX) as stream:
  stream.settimeout(15);stream.connect(str(endpoint));stream.sendall(json.dumps(request).encode()+b'\n')
  result=json.loads(stream.makefile('rb').readline())
  assert result['response']!='error',result
  return result['data']

def snap(endpoint):return raw(endpoint,{'command':'snapshot'})
def cli(*args):
 p=subprocess.run([str(BINARY),*map(str,args)],capture_output=True,text=True,timeout=110)
 assert p.returncode==0,(args,p.stderr[-1500:])
 return json.loads(p.stdout)

def unchanged(before,after):
 for key in ['host_id','host_pid','provider_pid','owner','journal_total','operation_ids','pending_requests','admission']:
  assert before[key]==after[key],key

def observe(endpoint,thread,turn,timeout=90000):
 return cli('session',endpoint,'wait',thread,turn,'--timeout-ms',timeout)

try:
 for provider in ['opencodex','deepseek']:
  home=ROOT/provider;home.mkdir(mode=0o700);state=home/'provider-home';state.mkdir(mode=0o700)
  directory=home/'workspace';directory.mkdir();env=os.environ.copy()
  if provider=='opencodex':
   env={k:v for k,v in env.items() if not k.startswith(('CODEX_','OPENAI_'))};env['CODEX_HOME']=str(state)
   (state/'config.toml').write_text('model = "gpt-6.1-sol"\nmodel_provider = "opencodex"\napproval_policy = "never"\n[model_providers.opencodex]\nname = "Existing OpenCodex loopback proxy"\nbase_url = "http://127.0.0.1:10100/v1"\nwire_api = "responses"\nrequires_openai_auth = false\nrequest_max_retries = 0\nstream_max_retries = 0\n')
  else:
   env['DSH_HOME']=str(state);credential=state/'.credentials.yaml';shutil.copyfile(Path.home()/'.dsh/.credentials.yaml',credential);credential.chmod(0o600);credentials.append(credential)
  endpoint=home/'host/control.sock';log=home/'host.log'
  with log.open('w') as output:
   process=subprocess.Popen([str(BINARY),'serve-acp' if provider=='deepseek' else 'serve',str(endpoint),str(home)],env=env,stdout=subprocess.DEVNULL,stderr=output,start_new_session=True)
  owned.append((process,endpoint));end=time.monotonic()+30
  while not(endpoint.exists() and 'ready:' in log.read_text()):
   assert process.poll() is None,log.read_text()
   assert time.monotonic()<end,'owned provider readiness deadline'
   time.sleep(.05)
  record={'provider':provider,'version':subprocess.check_output(['dsh' if provider=='deepseek' else 'codex','--version'],text=True).strip(),'results':[]}
  receipt['providers'].append(record)
  thread=cli('session',endpoint,'--take-control','create',directory)['result']['thread']['id']
  previous=None
  for index in range(2):
   token=f'WAIT-{provider.upper()}-{index+1}-20261022'
   sent=cli('session',endpoint,'--take-control','send',thread,f'Only reply with this exact token: {token}. Do not use tools or modify files.')
   turn=sent['result']['turn']['id'];before=snap(endpoint)
   assert any(t['thread_id']==thread and t['turn_id']==turn for t in before['activity']['turns']),before['activity']
   result={'thread':thread,'turn':turn,'token':token,'before':before}
   record['results'].append(result)
   if previous:
    older=observe(endpoint,thread,previous)
    assert older['outcome']=='finished' and older['turn']['id']==previous,older
    result['older_during_next_turn']=older
   observed=observe(endpoint,thread,turn)
   assert observed['outcome']=='finished' and observed['turn']['status']=='completed',observed
   after=snap(endpoint);unchanged(before,after)
   settled=observe(endpoint,thread,turn);unchanged(after,snap(endpoint))
   assert settled['outcome']=='finished' and settled['turn']['id']==turn,settled
   params={'threadId':thread,'includeTurns':True}
   history=raw(endpoint,{'command':'query','lease':after['owner'],'method':'thread/read','params':params})['message']['result']['thread']
   text='\n'.join(item['text'] if item['type']=='agentMessage' else ''.join(block['text'] for block in item['content'] if block['type']=='text') for t in history['turns'] if t['id']==turn for item in t['items'] if item['type'] in ['agentMessage','acpMessage'])
   assert token in text,(token,text)
   result.update({'observed':observed,'settled':settled,'after':after,'assistant_text':text})
   previous=turn
   (ROOT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
   print(provider,index+1,'pass',flush=True)
finally:
 for process,endpoint in reversed(owned):
  provider_pid=None
  if process.poll() is None:
   provider_pid=snap(endpoint)['provider_pid'];os.killpg(process.pid,signal.SIGINT);process.wait(timeout=15)
  assert not endpoint.exists(),str(endpoint)
  for pid in [process.pid,provider_pid]:
   if pid is not None:
    stat=Path('/proc')/str(pid)/'stat';assert not stat.exists() or stat.read_text().split(') ')[1].startswith('Z '),pid
  receipt['cleanup'].append({'host_pid':process.pid,'provider_pid':provider_pid,'exit_code':process.returncode,'socket_removed':not endpoint.exists(),'processes_gone_or_zombie':True})
 for credential in credentials:credential.unlink();assert not credential.exists()
 receipt['private_credentials_removed']=True
 (ROOT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PASS')
